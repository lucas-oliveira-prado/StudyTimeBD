<?php
    include('C:\Users\Pichau\Downloads\biblioteca-BD-main-20221204T191302Z-001\biblioteca-BD-main\config.php');

    if (!isset($_GET['id'])) {
        echo "Disciplina não encontrada para edição";
    } else {
        $id = $_GET['id'];
        if($_POST['nome'] == "") {
            echo "Por favor, informe o nome da disciplima";
        } else {
            $nome = $_POST['nome'];

            $sql = "UPDATE disciplina SET nome = '$nome' WHERE id = $id;";

            if ($mysqli->query($sql) == true) {
                echo "Disciplina editada";
            } else {
                echo "Erro ao editar a disciplina, tente novamente mais tarde.";
            }
            $mysqli->close();
        }
    }
?>
<br/><br/>
<button type="button" onclick="location.href='../index.php'">Voltar</button>
