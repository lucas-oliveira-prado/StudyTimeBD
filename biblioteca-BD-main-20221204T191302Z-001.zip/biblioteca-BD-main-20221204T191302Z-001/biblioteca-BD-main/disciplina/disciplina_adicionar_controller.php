<?php
    include('C:\Users\Pichau\Downloads\biblioteca-BD-main-20221204T191302Z-001\biblioteca-BD-main\config.php');

    if($_POST['nome'] == "") {
        echo "Por favor, informe o nome da displina";
    } 
    else{
        $nome_disciplina = $_POST['nome'];

        $sql = "INSERT INTO disciplina (nome) VALUES ('$nome_disciplina');";

        if ($mysqli->query($sql) == true) {
            echo "Disciplina adicionada";
        } else {
            echo "Erro ao adicionar a disciplina, tente novamente mais tarde.";
        }
        $mysqli->close();
    }
?>
<br/><br/>
<button type="button" onclick="location.href='adicionar.php'">Voltar</button>
