<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Study Time</title>
    </head>
    <body>
        <h2>Adicionar Disciplina</h2>
        <small>*campos obrigatórios</small>
        <br/><br/>
        <form action="disciplina_adicionar_controller.php" method="post">
            <label for="nome">Nome*</label>
            <input type="text" name="nome" id="nome" required="true" maxlength="60"/>
            <br/><br/>
            <button type="button" onclick="location.href='../index.php'">Voltar</button>
            <button type="submit">Salvar</button>
        </form>
    </body>
</html>
