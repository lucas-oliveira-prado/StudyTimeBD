<?php
    include('C:\Users\Pichau\Downloads\biblioteca-BD-main-20221204T191302Z-001\biblioteca-BD-main\config.php');

    if (!isset($_GET['id'])) {
        echo "Disciplina não encontrada para exclusão";
    } else {
        $id = $_GET['id'];
        $sql = "DELETE FROM disciplina WHERE id = $id;";
        if ($mysqli->query($sql) == true) {
            echo "Disciplina excluída";
        } else {
            echo "Erro ao excluir a disciplina, tente novamente mais tarde.";
        }
        $mysqli->close();
    }
?>
<br/><br/>
<button type="button" onclick="location.href='../index.php'">Voltar</button>
