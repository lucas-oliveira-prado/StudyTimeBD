<!DOCTYPE html>
<?php 
    include('C:\Users\Pichau\Downloads\biblioteca-BD-main-20221204T191302Z-001\biblioteca-BD-main\config.php');

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $sql = "SELECT tema FROM topico WHERE id = $id;";
        if ($result = $mysqli->query($sql)) {
            $row = $result->fetch_row();
            $nome = $row[0];
        }
    }

?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Study Time</title>
    </head>
    <body>
        <h2>Editar Tópicos</h2>
        <small>*campos obrigatórios</small>
        <br/><br/>
        <form action="topico_editar_controller.php?id=<?php echo $id; ?>" method="post">
            <label for="nome">Tema*</label>
            <input type="text" name="tema" id="tema" required="true" value="<?php echo $nome; ?>" maxlength="60"/>
            <br/><br/>
            <button type="button" onclick="location.href='../index.php'">Voltar</button>
            <button type="submit">Salvar</button>
        </form>
    </body>
</html>
