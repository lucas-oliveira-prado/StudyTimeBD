<?php
    include('C:\Users\Pichau\Downloads\biblioteca-BD-main-20221204T191302Z-001\biblioteca-BD-main\config.php');

    if (!isset($_GET['id'])) {
        echo "Tópico não encontrado para edição";
    } else {
        $id = $_GET['id'];
        if($_POST['tema'] == "") {
            echo "Por favor, informe o nome do tópico";
        } else {
            $nome = $_POST['tema'];

            $sql = "UPDATE topico SET nome = '$nome' WHERE id = $id;";

            if ($mysqli->query($sql) == true) {
                echo "Tópico editado";
            } else {
                echo "Erro ao editar o tópico, tente novamente mais tarde.";
            }
            $mysqli->close();
        }
    }
?>
<br/><br/>
<button type="button" onclick="location.href='../index.php'">Voltar</button>
