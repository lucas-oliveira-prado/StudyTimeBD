<?php
    include('C:\Users\Pichau\Downloads\biblioteca-BD-main-20221204T191302Z-001\biblioteca-BD-main\config.php');

    if($_POST['tema'] == "") {
        echo "Por favor, informe o tema do tópico";
    } else {
        $nome_topico = $_POST['tema'];

        $sql = "INSERT INTO topico (tema) VALUES ('$nome_topico');";

        if ($mysqli->query($sql) == true) {
            echo "Tópico adicionada";
        } else {
            echo "Erro ao adicionar o tópico, tente novamente mais tarde.";
        }
        $mysqli->close();
    }
?>
<br/><br/>
<button type="button" onclick="location.href='adicionar.php'">Voltar</button>
