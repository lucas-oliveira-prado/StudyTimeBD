<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Study Time</title>
    </head>
    <body>
        <h2>Adicionar Tópicos</h2>
        <small>*campos obrigatórios</small>
        <br/><br/>
        <form action="topico_adicionar_controller.php" method="post">
            <label for="nome">Tema*</label>
            <input type="text" name="tema" id="tema" required="true" maxlength="100"/>
            <br/><br/>
            <button type="button" onclick="location.href='../index.php'">Voltar</button>
            <button type="submit">Salvar</button>
        </form>
    </body>
</html>
