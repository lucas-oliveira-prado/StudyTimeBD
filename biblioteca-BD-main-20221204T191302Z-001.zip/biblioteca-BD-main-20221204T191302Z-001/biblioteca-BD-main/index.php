<!DOCTYPE html>
<?php include('config.php'); ?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Study Time</title>
    </head>
    <body>
        <marquee><h1>Study Time - Sistema de Gerenciamento de Estudos</h1></marquee>
        <hr/>
        <h2>Gerenciar Disciplina</h2>
        <button onclick="location.href='disciplina/adicionar.php'">Adicionar</button>
        <br/><br/>
        <table border="1px">
            <tr>
                <th>Nome</th>
                <th>Opções</th>
            </tr>
            <?php
                $sql = "SELECT id, nome FROM disciplina ORDER BY nome;";
                if ($result = $mysqli->query($sql)) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['nome'] . "</td>";
                        echo "<td>";
                        echo "<button type=\"button\" onclick=\"location.href='disciplina/editar.php?id=" . $row['id'] . "'\">Editar</button>";
                        echo "<button type=\"button\" onclick=\"location.href='disciplina/disciplina_excluir_controller.php?id=" . $row['id'] . "'\">Excluir</button>";
                        echo "</td>";
                        echo "<tr>";
                    }
                }
            ?>
        </table>
        <br/>
        <hr/>
        <h2>Gerenciar Tópicos</h2>
        <button onclick="location.href='topico/adicionar.php'">Adicionar</button>
        <br/><br/>
        <table border="1px">
            <tr>
                <th>Tema</th>
                <th>Opções</th>
            </tr>
            <?php
                $sql = "SELECT id, tema FROM topico ORDER BY tema;";
                if ($result = $mysqli->query($sql)) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['tema'] . "</td>";
                        echo "<td>";
                        echo "<button type=\"button\" onclick=\"location.href='topico/editar.php?id=" . $row['id'] . "'\">Editar</button>";
                        echo "<button type=\"button\" onclick=\"location.href='topico/topico_excluir_controller.php?id=" . $row['id'] . "'\">Excluir</button>";
                        echo "</td>";
                        echo "<tr>";
                    }
                }
            ?>
        </table>
        <br/>
        <hr/>
        <br/>
        <hr/>
        <h2>Quantidade de Disciplinas cadastradas</h2>
        <table border="1px">
            <tr>
                <th>Disciplinas</th>
            </tr>
            <?php
                $sql = "SELECT COUNT(disciplina.id) AS quantidadeDisciplina FROM disciplina;";
                if ($result = $mysqli->query($sql)) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['quantidadeDisciplina'] . "</td>";
                        echo "<tr>";
                    }
                }
            ?>
        </table>
        <br/>
        <hr/>
    </body>
</html>
